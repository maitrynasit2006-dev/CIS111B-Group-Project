/**
 * External feature provider for the project.
 * Can return a motivational quote (placeholder or real API).
 */

public class ExternalService {

    public String getMotivationalQuote() {
        return "You got this! Small steps count.";
    }
}
